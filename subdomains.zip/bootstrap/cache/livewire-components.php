<?php return array (
  'admin-management' => 'App\\Http\\Livewire\\AdminManagement',
  'domain-management' => 'App\\Http\\Livewire\\DomainManagement',
  'edit-admin' => 'App\\Http\\Livewire\\EditAdmin',
  'edit-domain' => 'App\\Http\\Livewire\\EditDomain',
  'edit-user' => 'App\\Http\\Livewire\\EditUser',
  'user-management' => 'App\\Http\\Livewire\\UserManagement',
);